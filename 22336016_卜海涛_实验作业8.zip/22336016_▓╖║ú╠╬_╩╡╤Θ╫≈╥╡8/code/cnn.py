import torch.nn as nn
from torchvision import transforms
from torch.utils.data import Dataset
import torch
from PIL import Image
from torch.optim import lr_scheduler
import matplotlib.pyplot as plt

#数据预处理，该类作用是串行白化、中心化、归一化等变换操作
Data_transform=transforms.Compose([
    #将图片进行统一缩放
    transforms.Resize((224,224)),
    #将每张图片转成通道为3的二维矩阵
    transforms.ToTensor(),
    #图片归一化
    transforms.Normalize(mean=[0.485, 0.456, 0.406],std=[0.229, 0.224, 0.225])
])

#加载数据集的类,其中Dataset是一个自定义数据集方法的类
class MyDataset(Dataset):
    def __init__(self,txt_path):
        #imgs是存储每张图片路径的列表,labels存储图片标签
        imgs=[]
        labels=[]
        Read=open(txt_path,'r')
        for i in Read:
            #删除换行符
            i=i.rstrip()
            #分割图片路径与编号
            img=i.split(':')
            #放入图片列表
            imgs.append(img[0])
            labels.append(int(img[1]))
        self.imgs=imgs
        self.labels=labels
    #定义函数返回数据集大小
    def __len__(self):
        return len(self.imgs)
    
    #定义函数对数据集中指定索引的图片进行处理
    def __getitem__(self, index):
        #使用PIL库读取图片
        img=Image.open(self.imgs[index])
        #对图片预处理，变成三层的二维矩阵
        img=Data_transform(img)
        label=self.labels[index]
        return img,label
    
#建立神经网络
class CNN(nn.Module):
    def __init__(self):
        #初始化继承父类的属性
        super(CNN,self).__init__()
        #卷积层
        #定义一个装载神经网络运算的容器
        #第一层卷积
        self.conv1=nn.Sequential(
            #（矩阵卷积）函数，相当于过滤器
            nn.Conv2d(
                in_channels=3,#输入是灰度图则为1，彩色图则为3
                out_channels=64,#表示有多少组卷积核，输出的矩阵有多少个
                kernel_size=3,#3*3的矩阵即可
                stride=1,#步长为1
                padding=1,#早期程要保留尽可能多的信息，保证卷积后的图片尺寸与原图相同，否则图片尺寸会越来越小
            ),
            #进入激励层之前最好先对数据进行归一化
            nn.BatchNorm2d(num_features=64),
            #激励函数
            nn.ReLU(inplace=True),
            #二维池化（压缩数据，减少过拟合）
            nn.MaxPool2d(
                kernel_size=2,#池化核大小，通常为2*2
                stride=2,#步长为2
            ),
        )

        #第二层卷积
        self.conv2=nn.Sequential(
            nn.Conv2d(64,128,3,1,1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2,2),
        )

        #第三层卷积
        self.conv3=nn.Sequential(
            nn.Conv2d(128,256,3,1,1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(4,4),
        )

        #输出层/全连接层
        self.output=nn.Sequential(
            #以0.5的概率删除部分隐藏层，防止数据过拟合
            nn.Dropout(0.5),
            nn.Linear(256*14*14,256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            
            nn.Dropout(0.5),
            nn.Linear(256,256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),

            nn.Dropout(0.5),
            #样本数据集中只有5个类别
            nn.Linear(256,5),
        )

    #前向传播，计算模型的误差
    def forward(self,x):
        #卷积进行特征提取
        x=self.conv1(x)
        x=self.conv2(x)
        x=self.conv3(x)
        #展平，从卷积层过渡到全连接层
        x=x.flatten(1)
        #分类得到预测值
        x=self.output(x)
        return x
    
#使用训练集进行训练
def Train(epoch,model,device,criterion,optim,lr_scheduler,train_loader):
    Losses=[]
    Accuracies=[]
    #对训练集训练epoch次
    for i in range(epoch):
        #训练模式要执行BN与dropout层
        model.train()
        #开启学习率调度
        lr_scheduler.step()

        for j,(imgs,labels) in enumerate(train_loader):
            print("epoch:{} batch:{}".format(i+1,j+1))
            imgs=imgs.to(device)
            labels=labels.to(device)
            imgs=imgs.reshape(-1,3,224,224)
            #输入经过模型得到输出
            outputs=model(imgs)
            #使用交叉熵计算损失
            loss=criterion(outputs,labels)
            Losses.append(loss.item())
            #将上一次的梯度置为0
            optim.zero_grad()
            #向后传播计算梯度
            loss.backward()
            #梯度下降进行参数更新
            optim.step()
        
        model.eval()
        correct_Train=0
        #禁止梯度的计算，节省内存
        with torch.no_grad():
            for imgs,labels in train_loader:
                imgs=imgs.to(device)
                labels=labels.to(device)
                imgs=imgs.reshape(-1,3,224,224)
                #训练集通过模型得到预测输出
                outputs=model(imgs)
                #获取预测标签
                predict=outputs.data.max(1,keepdim=True)[1]
                correct_Train+=predict.eq(labels.data.view_as(predict)).cpu().sum()
        Accuracies.append(correct_Train / len(train_loader.dataset))
    return Losses,Accuracies


#计算准确率
def Accurary(model,device,train_loader,test_loader):
    #测试模式不经过BN层与dropout层
    model.eval()
    correct_Train=0
    correct_Test=0
    #禁止梯度的计算，节省内存
    with torch.no_grad():
        for imgs,labels in train_loader:
            imgs=imgs.to(device)
            labels=labels.to(device)
            imgs=imgs.reshape(-1,3,224,224)
            #训练集通过模型得到预测输出
            outputs=model(imgs)
            #获取预测标签
            predict=outputs.data.max(1,keepdim=True)[1]
            correct_Train+=predict.eq(labels.data.view_as(predict)).cpu().sum()

        for imgs,labels in test_loader:
            imgs=imgs.to(device)
            labels=labels.to(device)
            imgs=imgs.reshape(-1,3,224,224)
            #训练集通过模型得到预测输出
            outputs=model(imgs)
            #获取预测标签
            predict=outputs.data.max(1,keepdim=True)[1]
            correct_Test+=predict.eq(labels.data.view_as(predict)).cpu().sum()

    print('\nTrain Accuracy: {}/{} ({:.3f}%)\n'.format(correct_Train, len(train_loader.dataset),
    100. * correct_Train / len(train_loader.dataset)))

    print('\nTest Accuracy: {}/{} ({:.3f}%)\n'.format(correct_Test, len(test_loader.dataset),
    100. * correct_Test / len(test_loader.dataset)))


if __name__ == '__main__':
    train_data=MyDataset('train.txt')
    test_data=MyDataset('test.txt')
    #对训练数据进行分批处理
    train_loader=torch.utils.data.DataLoader(train_data,batch_size=128,shuffle=True,num_workers=0,pin_memory=True)
    test_loader=torch.utils.data.DataLoader(test_data,batch_size=128,shuffle=False,num_workers=0,pin_memory=False)
    #将网络操作移动到GPU或CPU
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    #神经网络模型
    model=CNN().to(device)
     #交叉熵损失函数
    criterion=nn.CrossEntropyLoss().to(device)
    #定义模型优化器：输入模型参数，定义初始学习率
    optim=torch.optim.Adam(model.parameters(),lr=0.001)
    # 定义学习率调度器：输入包装的模型，定义学习率衰减周期step_size，gamma为衰减的乘法因子
    exp_lr_scheduler = lr_scheduler.StepLR(optim, step_size=6, gamma=0.1)
    Losses,Accuracies=Train(5,model,device,criterion,optim,exp_lr_scheduler,train_loader)
    #设置画布大小
    index1=[i for i in range(len(Losses))]
    index2=[i for i in range(len(Accuracies))]
    plt.figure(figsize=(50,5))
    #绘制损失曲线
    plt.subplot(1,2,1)
    plt.plot(index1,Losses)  
    plt.title('Scatter Plot of Losses')
    plt.xlabel('batch')
    plt.ylabel('Loss')
    #绘制准确率曲线
    plt.subplot(1,2,2)
    plt.plot(index2,Accuracies)  
    plt.title('Scatter Plot of Accuracies')
    plt.xlabel('epoch')
    plt.ylabel('Accuracy')
    plt.show()
    #计算准确率
    Accurary(model,device,train_loader,test_loader)
    