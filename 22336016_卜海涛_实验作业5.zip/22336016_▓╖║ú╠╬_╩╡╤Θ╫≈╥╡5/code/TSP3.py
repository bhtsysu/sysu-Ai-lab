import numpy as np
import matplotlib.pyplot as plt #绘图模块
import random
class GeneticAlgTSP:
    def __init__(self,filename):
        self.cities=[]
        #存放城市间的数据
        self.population=[]
        #存放初始种群
        self.num=0
        #表示种群容量
        with open(filename) as file_object:
            for line in file_object.readlines():
              if line[0]>='0' and line[0]<='9':
                temp=line.rstrip()
                temp=temp.split()
                self.cities.append(temp[1:]) 
            self.cities=np.array(self.cities)
            self.cities=self.cities.astype(np.float64)

    def cost(self,trail): #利用numpy库操作计算一种路径的代价
        s=0
        for i in range(len(trail)-1):
            s+=np.linalg.norm(self.cities[trail[i]]-self.cities[trail[i+1]])
        s+=np.linalg.norm(self.cities[trail[0]]-self.cities[trail[len(trail)-1]])
        #还要加上首位相连的距离
        return s

    def initial(self,num): #num是初始种群中的个体数量
        self.num=num
        length=len(self.cities)
        for i in range(num):
            temp=random.sample(range(0,length),length)
            self.population.append(temp)
        #随机数生成大小为num的初始种群
            
    def reproduce(self,dad,mum): #交叉
        length=len(dad)
        left,right=random.sample(range(0,length),2)
        if left>right:
            left,right=right,left
        #随机选择两个下标进行交叉
        child=[]
        #孩子列表
        temp1=dad[left:right]
        c1=[]
        c2=[]
        for i in range(0,length):
            if mum[i] not in temp1:
                if i<left:
                    c1.append(mum[i])
                else:
                    c2.append(mum[i])
        temp1=c1+temp1+c2
        temp2=mum[left:right]
        c1=[]
        c2=[]
        for i in range(0,length):
            if dad[i] not in temp2:
                if i<left:
                    c1.append(dad[i])
                else:
                    c2.append(dad[i])
        temp2=c1+temp2+c2
        child.append(temp1)
        child.append(temp2)
        #交叉产生后代
        return child   
    
    def mutation(self,child): #变异
        length=len(child)
        left,right=random.sample(range(0,length),2)
        if left>right:
            left,right=right,left
        #随机选择两个下标进行变异
        temp=[]
        for i in range(0,left):
            temp.append(child[i])
        for i in range(right,left-1,-1):
            temp.append(child[i])
        for i in range(right+1,len(child)):
            temp.append(child[i])
        #倒置变异
        return temp
    
    def iterate(self,num_iterations,num_reproduce,rate): #函数参数为迭代次数与变异概率
        i=0
        x2=[]
        y2=[]
        for i in range(num_iterations):
            new_population=[]
            weight=[] #记录种群中每个个体的权重
            for k in range(len(self.population)):
                new_population.append(self.population[k])
                weight.append(1/self.cost(self.population[k])) #适应度越好概率越大
            for j in range(num_reproduce):
                dad=[]
                mum=[]
                while dad==mum:
                    dad=random.choices(self.population,weight,k=1)
                    mum=random.choices(self.population,weight,k=1)
                #轮盘转方式选择两个不相同的亲本
                child=self.reproduce(dad[0],mum[0])
                #两个亲本进行杂交生成孩子列表
                if random.random()<=rate:
                    child[0]=self.mutation(child[0])
                    child[1]=self.mutation(child[1])
                while child[0]==child[1]:
                    child[0]=self.mutation(child[0])
                    child[1]=self.mutation(child[1])
                new_population.append(child[0])
                new_population.append(child[1])
            min=float('inf')
            index=-1
            for j in range(len(self.population)):
                if self.cost(self.population[j])<min:
                    min=self.cost(self.population[j])
                    index=j
            #最小代价
            temp=self.population[index]
            self.population.clear()
            weight.clear()
            for k in range(len(new_population)):
                weight.append(1/self.cost(new_population[k])) #适应度越好概率越大
            for k in range(self.num-1):
                single=random.choices(new_population,weight,k=1)
                self.population.append(single[0])
            self.population.append(temp)
            new_population.clear()
            #保留种群中的最佳个体到下一代
            x1=[]
            y1=[]
            for j in range(len(temp)):
                x1.append(self.cities[temp[j]][0])
                y1.append(self.cities[temp[j]][1])
            x1.append(self.cities[temp[0]][0])
            y1.append(self.cities[temp[0]][1])

            plt.figure(1)
            plt.clf()
            #清空原先图像
            plt.plot(x1,y1,'o')
            #显示点
            plt.plot(x1,y1,'r-')
            #显示线
            plt.grid()
            #显示网格
            plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
            plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
            plt.xlabel('横向空间位置')
            plt.ylabel('纵向空间位置')
            plt.title(f'种群容量：{self.num}     交叉次数：{num_reproduce}     迭代次数：{i}     变异概率：{rate}     最优路径长度：{min}')
            plt.pause(0.01)

            x2.append(i+1)
            y2.append(min)
            plt.figure(2)
            plt.clf()
            plt.plot(x2,y2,'r-')
            #显示线
            plt.grid()
            #显示网格
            plt.pause(0.01)

        index=-1
        min=float('inf')
        for j in range(len(self.population)):
            if self.cost(self.population[j])<min:
                min=self.cost(self.population[j])
                index=j
        temp=self.population[index]
        #最小代价
        x1=[]
        y1=[]
        for j in range(len(temp)):
            x1.append(self.cities[temp[j]][0])
            y1.append(self.cities[temp[j]][1])
        x1.append(self.cities[temp[0]][0])
        y1.append(self.cities[temp[0]][1])
        plt.clf()
        #清空原先图像
        plt.plot(x1,y1,'o')
        #显示点
        plt.plot(x1,y1,'r-')
        #显示线
        plt.grid()
        #显示网格
        plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
        plt.xlabel('横向空间位置')
        plt.ylabel('纵向空间位置')
        plt.title(f'种群容量：{self.num}     交叉次数：{num_reproduce}     迭代次数：{i+1}     变异概率：{rate}     最优路径长度：{min}')

        x2.append(i+1)
        y2.append(min)
        plt.figure(2)
        plt.clf()
        plt.plot(x2,y2,'r-')
        #显示线
        plt.grid()
        #显示网格
        plt.show()

        for i in range(len(temp)):
            print(temp[i], end='')
            print('->', end='')  
        print(temp[0])
        print(min)
TSP = GeneticAlgTSP('dj38.tsp')
TSP.initial(100)
TSP.iterate(10000,10,0.3)