import numpy as np
import matplotlib.pyplot as plt
import random
class Percept:
    def __init__(self,filename):
        self.data=np.genfromtxt(filename,delimiter=',',skip_header=1)
        for i in range(len(self.data)):
            if self.data[i][-1]==0:
                self.data[i][-1]=-1
    
    #归一化
    def Max_Min(self,X):
        Max=np.max(X,axis=0)
        Min=np.min(X,axis=0)
        X_Max_Min=(X-Min)/(Max-Min)
        return X_Max_Min,Max,Min
    
    #标准化
    def standardlize(self,X):
        Mean=np.mean(X,axis=0)
        Std=np.std(X,axis=0)
        X_standardlize=(X-Mean)/Std
        return X_standardlize,Mean,Std
    
    #sgn函数
    def sgn(self,z):
        sgn_z=[1 if i>=0 else -1 for i in z]
        return sgn_z
    
    #找到误差点
    def Select(self,X_train,y_train,weights,bias):
        new_X=[]
        new_y=[]
        for i in range(len(X_train)):
            if -1*(X_train[i][0]*weights[0]+X_train[i][1]*weights[1]+bias)*y_train[i]>0:
                new_X.append(X_train[i])
                new_y.append(y_train[i])
        new_X=np.array(new_X)
        new_y=np.array(new_y)
        return new_X,new_y

    #划分训练集和测试集,按照1:4比例
    def train_and_test(self,rate=0.2):
        np.random.shuffle(self.data)
        n_train=int(self.data.shape[0]*rate)
        X_train=self.data[n_train:,:-1]
        y_train=self.data[n_train:,-1]
        X_test=self.data[:n_train,:-1]
        y_test=self.data[:n_train,-1]
        return X_train,X_test,y_train,y_test
    
    #迭代
    def iteration(self,times,steps,X_train,y_train):
        #生成标准正态分布随机数能加速训练过程并提高模型性能
        weights=np.random.randn(X_train.shape[1])
        bias=np.random.randn()
        # weights=np.array([0.55100302,-1.20777886])
        # bias=0.49493223267531056
        # weights=np.array([-1.12699593,-1.98117282])
        # bias=0.25690173756389895
        print(weights,bias)
        losses=[]
        i=0
        for i in range(times):
            new_X,new_y=self.Select(X_train,y_train,weights,bias)
            if new_X.shape[0]==0:
                break
            #从训练集中筛选出误分类点
            z=np.dot(new_X,weights.T)+bias #z=wx+b
            loss=-1*np.sum(new_y*z)
            #损失函数是误分类点到平面的总距离
            #梯度下降
            j=random.randint(0,len(new_X)-1)
            dw=new_y[j]*new_X[j]
            db=new_y[j]
            #更新权重
            weights+=steps*dw
            bias+=steps*db
            # print(loss)
            losses.append([])
            losses[len(losses)-1].append(i)
            losses[len(losses)-1].append(loss)
        new_X,new_y=self.Select(X_train,y_train,weights,bias)
        #从训练集中筛选出误分类点
        if new_X.shape[0]==0:
            loss=0
        else:
            z=np.dot(new_X,weights.T)+bias #z=wx+b
            loss=-1*np.sum(new_y*z)
        # print(loss)
        losses.append([])
        losses[len(losses)-1].append(i+1)
        losses[len(losses)-1].append(loss)
        losses=np.array(losses)
        return weights,bias,losses

    #对测试集的预测    
    def predict(self,X_test,weights,bias):
        z=np.dot(X_test,weights.T)+bias #z=wx+b
        y_predicted=self.sgn(z) #ò(wx+b)
        #将z映射为0和1
        return y_predicted    
        
    #计算准确率
    def accuracy(self,y_true,y_predict):
        accuracy = np.sum(y_true==y_predict)/len(y_true)
        return accuracy

    #绘图
    def Draw_Picture(self,X_train,y_train,weights,bias,losses,mean,std,Max,Min):
        #设置画布大小
        plt.figure(figsize=(50,5))
        # #绘制数据可视化图
        plt.subplot(1,3,1)
        plt.scatter(X_train[:,0],X_train[:,1],c=y_train,marker='o')  
        plt.title('Scatter Plot of Data')
        plt.xlabel('Age')
        plt.ylabel('Estimated Salary')
        #绘制预测分类图
        plt.subplot(1,3,2)
        plt.scatter(X_train[:,0],X_train[:,1],c=y_train,marker='o')  
        plt.title('prediction and classification')
        plt.xlabel('Age')
        plt.ylabel('Estimated Salary')
        #绘制分界线
        x_values=np.linspace(np.min(X_train[:,0]), np.max(X_train[:,0]), 100)   
        y_values=(-1*(weights[0]*((x_values-Min[0])/(Max[0]-Min[0])-mean[0])/std[0]+bias)*std[1]/weights[1]+mean[1])*(Max[1]-Min[1])+Min[1]
        # y_values=-1*(weights[0]*(x_values-mean[0])/std[0]+bias)*std[1]/weights[1]+mean[1]                                     
        plt.plot(x_values, y_values, color='red', linestyle='-', label='Decision Boundary')
        plt.legend()
        #绘制损失曲线
        plt.subplot(1,3,3)
        plt.plot(losses[:,0],losses[:,1],color='red')
        plt.title('Loss Curve')
        plt.xlabel('Iteration')
        plt.ylabel('Cross Entropy Loss')
        plt.show()

log=Percept('data.csv')
X_train,X_test,y_train,y_test=log.train_and_test()
X_train_Max_Min,Max,Min=log.Max_Min(X_train)
X_test_Max_Min,max,min=log.Max_Min(X_test)
X_train_standlize,Mean,Std=log.standardlize(X_train_Max_Min)
X_test_standlize,mean,std=log.standardlize(X_test_Max_Min)
weights,bias,losses=log.iteration(10000,0.01,X_train_standlize,y_train)
log.Draw_Picture(X_train,y_train,weights,bias,losses,Mean,Std,Max,Min)
y_predict_train=log.predict(X_train_standlize,weights,bias)
y_predict_test=log.predict(X_test_standlize,weights,bias)
print("Train accuarcy:",log.accuracy(y_train,y_predict_train))
print("Test accuarcy:",log.accuracy(y_test,y_predict_test))