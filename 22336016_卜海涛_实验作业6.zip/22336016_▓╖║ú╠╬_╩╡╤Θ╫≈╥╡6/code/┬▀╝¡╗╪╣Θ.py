import numpy as np
import matplotlib.pyplot as plt
class Logical:
    def __init__(self,filename):
        self.data=np.genfromtxt(filename,delimiter=',',skip_header=1)
        #用numpy库的genfromtxt函数导入数据集，delimiter设置数据用逗号分隔，skip_header设置为开头需要跳过的行数
        # self.X=data[:, :-1]
        #X取矩阵中每一行去掉最后一列的数据
        # self.y=data[:, -1]
        #y只取矩阵最后一列的数据
    
    #归一化
    def Max_Min(self,X):
        Max=np.max(X,axis=0)
        Min=np.min(X,axis=0)
        X_Max_Min=(X-Min)/(Max-Min)
        return X_Max_Min,Max,Min
    
    #标准化
    def standardlize(self,X):
        Mean=np.mean(X,axis=0)
        Std=np.std(X,axis=0)
        X_standardlize=(X-Mean)/Std
        return X_standardlize,Mean,Std
    
    #sigmod函数
    def sigmod(self,z):
        return 1/(1+np.exp(-z))#np库中的exp可以对数组、矩阵等多维数据进行运算
    
    #划分训练集和测试集,按照1:4比例
    def train_and_test(self,rate=0.2):
        np.random.shuffle(self.data)
        n_train=int(self.data.shape[0]*rate)
        X_train=self.data[n_train:,:-1]
        y_train=self.data[n_train:,-1]
        X_test=self.data[:n_train,:-1]
        y_test=self.data[:n_train,-1]
        return X_train,X_test,y_train,y_test
    
    #迭代
    def iteration(self,times,steps,X_train,y_train):
        #生成标准正态分布随机数能加速训练过程并提高模型性能
        weights=np.random.randn(X_train.shape[1])
        bias=np.random.randn()
        # [-1.03774872 -0.36198901] 1.4536960500855818
        # weights=np.array([-0.54128544,0.776823])
        # [-0.70786571  0.3971468 ] -0.5098026658822146
        # bias=-0.047643711157044355
        # weights=np.array([-0.70786571,0.3971468])
        # bias=-0.5098026658822146
        print(weights,bias)
        losses=[]
        i=0
        for i in range(times):
            z=np.dot(X_train,weights)+bias #z=wx+b
            y_predicted=self.sigmod(z) #ò(wx+b)
            #计算交叉熵成本函数(损失函数是对单个个体而言，成本函数对总体而言)
            loss=(-1/X_train.shape[0])*np.sum(y_train*np.log(y_predicted)+(1-y_train)*np.log(1-y_predicted))
            #梯度下降
            dw=(1/X_train.shape[0])*np.dot(X_train.T,(y_predicted-y_train))
            db=(1/X_train.shape[0])*np.sum(y_predicted-y_train)
            #更新权重
            weights-=steps*dw
            bias-=steps*db
            losses.append([])
            losses[len(losses)-1].append(i)
            losses[len(losses)-1].append(loss)
        z=np.dot(X_train,weights)+bias #z=wx+b
        y_predicted=self.sigmod(z) #ò(wx+b)
        loss=(-1/X_train.shape[0])*np.sum(y_train*np.log(y_predicted)+(1-y_train)*np.log(1-y_predicted))
        losses.append([])
        losses[len(losses)-1].append(i+1)
        losses[len(losses)-1].append(loss)
        losses=np.array(losses)
        return weights,bias,losses

    #对测试集的预测    
    def predict(self,X_test,weights,bias):
        z=np.dot(X_test,weights)+bias #z=wx+b
        y_predicted=self.sigmod(z) #ò(wx+b)
        #将sigmod(z)映射为0和1
        y_predicted=[1 if i>=0.5 else 0 for i in y_predicted]
        return y_predicted    
        
    #计算准确率
    def accuracy(self,y_true,y_predict):
        accuracy = np.sum(y_true==y_predict)/len(y_true)
        return accuracy

    #绘图
    def Draw_Picture(self,X_train,y_train,weights,bias,losses,mean,std,Max,Min):
        #设置画布大小
        plt.figure(figsize=(50,5))
        #绘制数据可视化图
        plt.subplot(1,3,1)
        plt.scatter(X_train[:,0],X_train[:,1],c=y_train,marker='o')  
        plt.title('Scatter Plot of Data')
        plt.xlabel('Age')
        plt.ylabel('Estimated Salary')
        #绘制预测分类图
        plt.subplot(1,3,2)
        plt.scatter(X_train[:,0],X_train[:,1],c=y_train,marker='o')  
        plt.title('prediction and classification')
        plt.xlabel('Age')
        plt.ylabel('Estimated Salary')
        #绘制分界线
        x_values=np.linspace(np.min(X_train[:,0]), np.max(X_train[:,0]), 100)
        # y_values=-1*(weights[0]*(x_values-mean[0])/std[0]+bias)/weights[1]*std[1]+mean[1]
        # y_values=-1*(weights[0]*(x_values-std[0])/(mean[0]-std[0])+bias)/weights[1]*(mean[1]-std[1])+std[1]
        y_values=(-1*(weights[0]*((x_values-Min[0])/(Max[0]-Min[0])-mean[0])/std[0]+bias)*std[1]/weights[1]+mean[1])*(Max[1]-Min[1])+Min[1]                                                   
        plt.plot(x_values, y_values, color='red', linestyle='-', label='Decision Boundary')
        plt.legend()
        #绘制损失曲线
        plt.subplot(1,3,3)
        plt.plot(losses[:,0],losses[:,1],color='red')
        plt.title('Loss Curve')
        plt.xlabel('Iteration')
        plt.ylabel('Cross Entropy Loss')
        plt.show()

log=Logical('data.csv')
X_train,X_test,y_train,y_test=log.train_and_test()
# X_train_standlize,Mean,Std=log.standardlize(X_train)
# X_test_standlize,mean,std=log.standardlize(X_test)
X_train_Max_Min,Max,Min=log.Max_Min(X_train)
X_test_Max_Min,max,min=log.Max_Min(X_test)
X_train_standlize,Mean,Std=log.standardlize(X_train_Max_Min)
X_test_standlize,mean,std=log.standardlize(X_test_Max_Min)
# X_train_Max_Min,Max,Min=log.Max_Min(X_train_standlize)
# X_test_Max_Min,max,min=log.Max_Min(X_test_standlize)
weights,bias,losses=log.iteration(10000,0.01,X_train_standlize,y_train)
# weights,bias,losses=log.iteration(5000,0.01,X_train_Max_Min,y_train)
log.Draw_Picture(X_train,y_train,weights,bias,losses,Mean,Std,Max,Min)
# log.Draw_Picture(X_train,y_train,weights,bias,losses,Max,Min)
y_predict_train=log.predict(X_train_standlize,weights,bias)
y_predict_test=log.predict(X_test_standlize,weights,bias)
# y_predict_train=log.predict(X_train_Max_Min,weights,bias)
# y_predict_test=log.predict(X_test_Max_Min,weights,bias)
print("Train accuarcy:",log.accuracy(y_train,y_predict_train))
print("Test accuarcy:",log.accuracy(y_test,y_predict_test))