import argparse
import gym#仿真游戏环境
from argument import dqn_arguments

#解析器
def parse():
    #解析器对象
    parser = argparse.ArgumentParser(description="SYSU_RL_HW2")
    #策略梯度法
    parser.add_argument('--train_pg', default=False, type=bool, help='whether train policy gradient')
    #DQN法
    parser.add_argument('--train_dqn', default=True, type=bool, help='whether train DQN')
    #将DQN参数加载到解析器
    parser = dqn_arguments(parser)
    #将PG参数加载到解析器
    #parser = pg_arguments(parser)
    #解析参数并返回
    args = parser.parse_args()
    return args


#根据解析的参数来进行对应的训练
def run(args):
    # if args.train_pg:
    #     env_name = args.env_name
    #     env = gym.make(env_name)
    #     from agent_pg import AgentPG
    #     agent = AgentPG(env, args)
    #     agent.run()

    if args.train_dqn:
        env_name = args.env_name
        env = gym.make(env_name,render_mode="human")
        from agent_dqn import AgentDQN
        agent = AgentDQN(env, args)
        agent.run()


if __name__ == '__main__':
    args = parse()
    run(args)
