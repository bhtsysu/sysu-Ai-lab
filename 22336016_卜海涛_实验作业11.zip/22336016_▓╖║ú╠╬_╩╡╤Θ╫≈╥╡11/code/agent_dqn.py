import os
import random
import copy
import numpy as np
import torch
from pathlib import Path
from tensorboardX import SummaryWriter
from torch import nn, optim
from agent import Agent
from tqdm import tqdm
import matplotlib.pyplot as plt
from torch.optim import Adam


#Q网络
class QNetwork(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        #super函数调用父类构造函数
        super(QNetwork, self).__init__()
        #构建两层神经网络
        self.layer=nn.Sequential(
            #输入是状态，有四个维度
            nn.Linear(input_size,hidden_size),
            nn.ReLU(),
            #输出是动作，只有两个维度
            nn.Linear(hidden_size,output_size),
            nn.ReLU()
        )

    def forward(self, inputs):
        #输入转为张量形式
        inputs=torch.Tensor(inputs)
        inputs=self.layer(inputs)
        return inputs

#经验回放
class ReplayBuffer:
    def __init__(self, buffer_size):
        self.buffer_size=buffer_size
        #创建经验池
        self.buffer=[]

    #返回经验池的长度
    def __len__(self):
        return len(self.buffer)

    #把数据加入经验池
    def push(self, *transition):
        #如果经验池已满弹出第一个元素
        if len(self.buffer)==self.buffer_size:
            self.buffer.pop(0)
        self.buffer.append(transition)

    #从经验池中随机采样并进行打包
    def sample(self, batch_size):
        batch=random.sample(self.buffer, batch_size)
        return zip(*batch)
        
    #清空经验池
    def clean(self):
        self.buffer.clear()

    
#DQN算法
class AgentDQN(Agent):
    def __init__(self, env, args):
        super(AgentDQN, self).__init__(env)
        self.args=args
        self.epsilon=1
        self.hidden_dim=64
        self.state_dim = self.env.observation_space.shape[0]
        self.action_dim = self.env.action_space.n
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.q_net = QNetwork(self.state_dim,self.hidden_dim,self.action_dim)
        self.target_q_net = QNetwork(self.state_dim, self.hidden_dim, self.action_dim).to(self.device)
        self.num_episodes=500
        self.replaybuffer=ReplayBuffer(5000)
        self.batch_size=128
        self.transition={}
        self.gamma=0.99
        self.optimizer = Adam(self.q_net.parameters(), lr=0.001)
        self.target_update = 100  # 目标网络更新频率
        self.count=0
        self.loss_fn=nn.MSELoss()

    def init_game_setting(self):
        pass

    def train(self):
        #让随机选取动作的概率逐步衰减
        if self.epsilon>0.05:
            self.epsilon*=0.999

        if self.count % self.target_update == 0:
            self.target_q_net.load_state_dict(self.q_net.state_dict())  # 更新目标网络
        self.count+= 1

        #将数据全部转换为张量形式
        states,actions,rewards,next_states,dones=self.replaybuffer.sample(self.batch_size)#获取经验学习
        actions = torch.LongTensor(actions)  # LongTensor to use gather latter
        dones = torch.FloatTensor(dones)
        rewards = torch.FloatTensor(rewards)
        #在线Q网络，用于根据当前状态选取动作并计算Q的预测值，通过gather方法选择动作
        q_values=self.q_net(np.array(states)).gather(1,actions.unsqueeze(1)).squeeze(1)
        #目标Q网络，预测下个状态的最大Q值
        q_next = torch.max(self.target_q_net(np.array(next_states)), dim = 1)[0]
        #使用TD方法计算Q的目标值
        q_targets=rewards+self.gamma*(1 - dones)*q_next
        #使用均方误差损失函数
        loss=self.loss_fn(q_values, q_targets)
        #PyTorch中默认梯度会累积,这里需要显式将梯度置为0
        self.optimizer.zero_grad() 
        loss.backward()#反向传播更新参数
        self.optimizer.step()

    def make_action(self, observation, test=True):
        #采用epsilon贪婪策略采取动作
        #探索过程，其中np.random.random()生成0~1的一个随机数
        if np.random.random()<=self.epsilon:
            action=np.random.randint(0,self.action_dim)
        #利用过程
        else:
            temp=torch.FloatTensor(observation)
            #选择动作时不进行梯度更新
            with torch.no_grad():
                action=self.q_net(temp).argmax().item()
        return action


    def run(self):
        returns=[]
        #500次测试
        for i in range(self.num_episodes):
            #初始化累积奖励为0
            discounted_return=0
            #初始化环境状态,每次的初始状态是随机的
            state=self.env.reset()[0]
            #完成标志done判断是否应该终止
            done=False
            while not done:
                #根据当前状态选择动作
                action=self.make_action(state)
                #采取行动，获取下一个状态，奖励，完成标志等
                next_state, reward,terminated,truncated,_ = self.env.step(action)
                done=terminated or truncated
                #将状态，动作，奖励以及下一个状态以元组形式放到经验池
                self.replaybuffer.push(state,action,reward,next_state,done)
                #经验池填满后开始对数据进行训练
                if self.replaybuffer.__len__()>=5000:
                    self.train()
                #更新状态和累计奖励
                state=next_state
                discounted_return+=reward
            print(f"Episode: {i}, Reward: {discounted_return}")
            #记录累计奖励变化情况
            returns.append(discounted_return)
        index1=[i for i in range(1,len(returns)+1)]
        plt.plot(index1,returns)
        plt.xlabel('Episodes')
        plt.ylabel('Returns')
        plt.title('CartPole-v0')
        plt.show()



                    
