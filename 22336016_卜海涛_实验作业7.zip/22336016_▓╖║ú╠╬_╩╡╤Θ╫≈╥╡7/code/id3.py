import operator
import random
from csv import reader
from math import log
class Dec_Tree:
    #初始化读入数据构建数据集
    def __init__(self,filename):
        #读取表格数据，放入data列表
        with open(filename, "r") as csv_file:
            csv_reader = reader(csv_file)
            data= list(csv_reader)
        #数据集
        self.DataSet=data[1:]
        for i in range(len(self.DataSet)):
            #对年龄属性离散化
            if int(self.DataSet[i][3])<=10:
                self.DataSet[i][3]='less'
            elif int(self.DataSet[i][3])>20:
                self.DataSet[i][3]='enough'
            else:
                self.DataSet[i][3]='middle'
            #给每条数据添加信誉标签
            if int(self.DataSet[i][2])<=30000:
                self.DataSet[i].append('NO')
            else:
                self.DataSet[i].append('YES')
            self.DataSet[i].pop(2)
        #属性集
        self.Attribute=data[0]
        self.Attribute.pop(2)
        #划分训练集和测试集
        random.shuffle(self.DataSet)
        self.TrainSet = self.DataSet[240:]
        self.ValidationSet = self.DataSet[120:240]
        self.TestSet = self.DataSet[:120]

    #计算标签的信息熵
    def LabelEnt(self,DataSet):
        #创建一个字典
        labelCounts={}
        #统计每种标签的出现次数
        for sample in DataSet:
            label=sample[-1]
            if label not in labelCounts.keys():
                labelCounts[label]=0
            labelCounts[label]+=1
        Ent=0.0
        #根据公式计算标签的信息熵
        for key in labelCounts:
            pro=float(labelCounts[key])/len(DataSet)
            Ent-=pro*log(pro,2)
        return Ent
    
    #根据属性及属性值划分出一个样本子集(相当于决策树的一个结点)
    def splitDataSet(self,DataSet,index,value):
        ChildSet=[]
        for sample in DataSet:
            if sample[index]==value:
                #去除这些样本的第index项，目的是防止下轮又选择了前一轮的最优化分
                newsample=sample[:index]
                newsample.extend(sample[index+1:])
                ChildSet.append(newsample)
        return ChildSet
    
    #根据信息增益选择最优的划分属性
    def BestChoice(self,DataSet):
        #标签的信息熵
        baseEnt=self.LabelEnt(DataSet)
        #初始化信息增益及最优划分序号
        bestGain=0.0
        bestAttribute=-1
        for i in range(len(DataSet[0])-1):
            #统计每个属性可能出现的特征值
            value=[sample[i] for sample in DataSet]
            value=set(value)
            #计算属性对应的条件熵
            CondiEnt=0
            for j in value:
                ChildSet=self.splitDataSet(DataSet,i,j)
                pro=len(ChildSet)/float(len(DataSet))
                CondiEnt+=pro*self.LabelEnt(ChildSet)
            #更新最优划分
            if(baseEnt-CondiEnt>bestGain):
                bestGain=baseEnt-CondiEnt
                bestAttribute=i
        return bestAttribute
    
    #寻找样本集中出现次数最多的标签（当没有属性可用于划分时少数服从多数）
    def MajorLabel(self,labelList):
        labelCounts={}
        for label in labelList:
            if label not in labelCounts.keys():
                labelCounts[label]=0
            labelCounts[label]+=1
        # 根据value值逆序排序labelCounts
        sortedLabelCounts=sorted(labelCounts.items(),key=operator.itemgetter(1),reverse=True)
        #返回第一个元素的第一个元素（标签）
        return sortedLabelCounts[0][0]

    #递归生成决策树
    def CreateTree(self,DataSet,labels):
        #当前样本集所有标签的列表
        labelList=[sample[-1] for sample in DataSet]
        #如果所有标签相同，划分结束
        if labelList.count(labelList[0])==len(labelList):
            return labelList[0]
        #若没有属性可划分，划分结束
        if(len(DataSet[0])==1):
            return self.MajorLabel(labelList)
        #获取当前最优划分的索引
        BestAttributeIndex=self.BestChoice(DataSet)
        #获取最优划分属性
        BestAttribute=labels[BestAttributeIndex]
        #用字典存储决策树的信息
        decisionTree={BestAttribute:{}}
        #删除已选中的最优属性
        del(labels[BestAttributeIndex])
        # 获取该属性可能的所有特征值
        values=[sample[BestAttributeIndex] for sample in DataSet]
        values=set(values)
        for i in values:
            subLabels=labels[:]
            decisionTree[BestAttribute][i]=self.CreateTree(self.splitDataSet(DataSet,BestAttributeIndex,i),subLabels)
        return decisionTree
    
    #对测试集进行分类(也要递归)
    def Classify(self,decisionTree,Testsample):
        #获取根节点属性
        rootAttribute=list(decisionTree.keys())[0]
        #根节点的value值及对应子节点的字典
        Child=decisionTree[rootAttribute]
        if type(Child)==str:
            return Child
        rootIndex=self.Attribute.index(rootAttribute)
        ClassLabel=""
        for value in Child.keys():
            #找到测试样本所属分支
            if Testsample[rootIndex]==value:
                #如果不是叶子节点
                if type(Child[value])==dict:
                    ClassLabel=self.Classify(Child[value],Testsample)
                #如果是叶子结点
                else:
                    ClassLabel=Child[value]
                break
        return ClassLabel
    
    #计算准确率
    def Accuracy(self):
        Attribute=self.Attribute[:]
        decisiontree=self.CreateTree(self.DataSet,Attribute)
        self.PostPrune(decisiontree, self.ValidationSet)
        TestLabel=[]
        Label=[]
        Right=0
        for sample in self.TestSet:
            TestLabel.append(self.Classify(decisiontree,sample))
            Label.append(sample[-1])
            if TestLabel[-1]==Label[-1]:
                Right+=1
        print(Label)
        print(TestLabel)
        print(float(Right)/len(self.TestSet))

        # 后剪枝
    def PostPrune(self, tree, ValidationSet):
        rootAttribute = list(tree.keys())[0]
        Child = tree[rootAttribute]
        for value in list(Child.keys()):
            if type(Child[value]) == dict:
                tree[rootAttribute][value] = self.PostPrune(Child[value], ValidationSet)
        leafLabel = self.MajorLabel([sample[-1] for sample in ValidationSet])
        beforePruneAcc = self.ValidationAccuracy(tree, ValidationSet)
        tree[rootAttribute] = leafLabel
        afterPruneAcc = self.ValidationAccuracy(tree, ValidationSet)
        if beforePruneAcc >= afterPruneAcc:
            tree[rootAttribute] = Child
        return tree
    
    # 计算验证集上的准确率
    def ValidationAccuracy(self, tree, ValidationSet):
        correct = 0
        for sample in ValidationSet:
            if self.Classify(tree, sample) == sample[-1]:
                correct += 1
        return correct / len(ValidationSet)


Tree=Dec_Tree('DT_data.csv')
Tree.Accuracy()