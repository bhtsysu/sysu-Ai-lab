import queue
import copy
def ResolutionF0L(KB):
    list1=[]
    list2=[]
    list3=[]
    for iter in KB:
        list1.append(list(iter))
        list2.append([])
        #把用元组存储的子句改为用列表存储，方便后续操作
    for i in range(len(list1)):
        for j in range(len(list1[i])):
            list1[i][j]=list1[i][j].split('(')
            list1[i][j][len(list1[i][j])-1]=list1[i][j][len(list1[i][j])-1].rstrip(')')
            list1[i][j][len(list1[i][j])-1]=list1[i][j][len(list1[i][j])-1].split(',')  
        #巧用split()切片把子句中每个文字拆分，谓词+常/变量组成一个列表
    i=0
    length=len(list1)
    while i!=len(list1):
        for ii in range(len(list1[i])):
            for j in range(0,i):
                for jj in range(len(list1[j])):
                    #将任意两子句的每个文字都两两匹配一次
                    str1=list1[i][ii][0]
                    str2=list1[j][jj][0]
                    if str1[0]=='~' and str2[0]!='~' or str2[0]=='~' and str1[0]!='~':
                        str1=str1.lstrip('~')
                        str2=str2.lstrip('~')
                        if str1!=str2:
                            break
                        #谓词名称相同，能进行归结
                        index1=list1[i][ii][1]
                        index2=list1[j][jj][1]
                        #常量和变量列表
                        if index1==index2:#列表中所有元素一一对应
                            newlist=[]
                            for k in range(len(list1[i])):
                                if k!=ii:
                                    if newlist.count(list1[i][k])==0:
                                        newlist.append(list1[i][k]) 
                                    #判断子句中是否已有该文字，有则不再加入
                            for k in range(len(list1[j])):
                                if k!=jj:
                                    if newlist.count(list1[j][k])==0:
                                        newlist.append(list1[j][k])
                            if list1.count(newlist)==0:
                            #判断原子句集中是否已存在新子句，有则不再加入，避免重复归结
                                list1.append(newlist)
                                list2.append([])
                            #list2列表是用于记录归结路径以及变量替换情况的
                                if len(list1[i])==1:
                                    list2[len(list2)-1].append(str(i+1))
                                else:
                                    list2[len(list2)-1].append(str(i+1)+chr(97+ii))
                                if len(list1[j])==1:
                                    list2[len(list2)-1].append(str(j+1))
                                else:
                                    list2[len(list2)-1].append(str(j+1)+chr(97+jj))
                            #记录归结路径，即新子句的两个父子句
                                if len(newlist)==0:
                                    Select(list1,list2,length)
                                    return
                                if len(newlist)==1:
                                    if Match(list1,list2,newlist,length)==1:
                                        return                                       
                        else:
                            temp1=copy.deepcopy(list1[i]) #深拷贝
                            temp2=copy.deepcopy(list1[j]) #深拷贝
                            q=0
                            Tlist=[]
                            if len(list1[i])==1:
                                Tlist.append(str(i+1))
                            else:
                                Tlist.append(str(i+1)+chr(97+ii))
                            if len(list1[j])==1:
                                Tlist.append(str(j+1))
                            else:
                                Tlist.append(str(j+1)+chr(97+jj))
                            for p in range(len(index1)):
                                #逐个匹配两文字的变量
                                if index1[p]!=index2[p]:
                                    if len(index1[p])>=3 and len(index2[p])>=3:
                                        q=1
                                        break
                                    #两个常量不一致，无法归结直接终止
                                    elif len(index1[p])<3:
                                        Tlist.append(index1[p])
                                        Tlist.append(index2[p])
                                        for k in range(len(temp1)):
                                            for kk in range(len(temp1[k][1])):
                                                if temp1[k][1][kk]==index1[p]:
                                                    temp1[k][1][kk]=index2[p]
                                    #其中一个是变量，则用常量替换变量
                                    else:
                                        Tlist.append(index2[p])
                                        Tlist.append(index1[p])
                                        for k in range(len(temp2)):
                                            for kk in range(len(temp2[k][1])):
                                                if temp2[k][1][kk]==index2[p]:
                                                    temp2[k][1][kk]=index1[p]
                                    #同上
                            if q==0:
                                newlist=[]
                                for k in range(len(temp1)):
                                    if k!=ii:
                                        if newlist.count(temp1[k])==0:
                                            newlist.append(temp1[k]) 
                                for k in range(len(temp2)):
                                    if k!=jj:
                                        if newlist.count(temp2[k])==0:
                                            newlist.append(temp2[k])
                                if list1.count(newlist)==0:
                                    list1.append(newlist)
                                    list2.append(Tlist)
                                    if len(newlist)==0:
                                        Select(list1,list2,length)
                                        return
                                    if len(newlist)==1:
                                        if Match(list1,list2,newlist,length)==1:
                                            return 
        i=i+1  
def Match(list1,list2,newlist,length):
    for i in range(len(list1)):
        if len(list1[i])==1:
            str1=newlist[0][0]
            str2=list1[i][0][0]
            if str1[0]=='~' and str2[0]!='~' or str2[0]=='~' and str1[0]!='~':
                str1=str1.lstrip('~')
                str2=str2.lstrip('~')
                if str1==str2:
                    if newlist[0][1]==list1[i][0][1]:
                        list1.append([])
                        list2.append([])
                        list2[len(list2)-1].append(str(list1.index(newlist)+1))
                        list2[len(list2)-1].append(str(i+1))
                        Select(list1,list2,length)
                        return 1
                    else:
                        q=0
                        Tlist=[]
                        ans1=list1.index(newlist)
                        Tlist.append(str(ans1+1))
                        Tlist.append(str(i+1))
                        for kk in range(len(list1[i][0][1])):
                            if len(newlist[0][1][kk])>=3 and len(list1[i][0][1][kk])>=3:
                                q=1
                                break
                            elif len(newlist[0][1][kk])<3:
                                Tlist.append(newlist[0][1][kk])
                                Tlist.append(list1[i][0][1][kk])
                            else: 
                                Tlist.append(list1[i][0][1][kk])
                                Tlist.append(newlist[0][1][kk])
                        if q==0:
                            list2.append(Tlist)
                            list1.append([])
                            Select(list1,list2,length)
                            return 1
    return 0
def Select(list1,list2,index):
    q=queue.Queue()
    #用队列找到归结树的结点
    q.put(len(list1)-1)
    newlist=[]
    while not q.empty():
        temp=q.get()
        newlist.append(temp)
        if len(list2[temp])!=0:
            str1=""
            for i in range(len(list2[temp][0])):
                if list2[temp][0][i]>='0' and list2[temp][0][i]<='9':
                    str1+=list2[temp][0][i]
            str2=""
            for i in range(len(list2[temp][1])):
                if list2[temp][1][i]>='0' and list2[temp][1][i]<='9':
                    str2+=list2[temp][1][i]
            #回溯寻找一个子句的两个亲本子句，加入到队列中
            q.put(int(str1)-1)
            q.put(int(str2)-1)
    newlist1=[]
    for i in range(index):
        newlist1.append(list1[i])
    for i in range(len(newlist)-1,-1,-1):
        if newlist1.count(list1[newlist[i]])==0:
            newlist1.append(list1[newlist[i]])
    newlist2=[]
    for i in range(len(newlist1)):
        newlist2.append([])
        if i>=index:
            ans=list1.index(newlist1[i])
            str1=list2[ans][0]
            str2=list2[ans][1]
            temp1=""
            for j in range(len(str1)):
                if str1[j]>='0' and str1[j]<='9':
                    temp1+=str1[j]
            temp2=""
            for j in range(len(str2)):
                if str2[j]>='0' and str2[j]<='9':
                    temp2+=str2[j]
            index1=newlist1.index(list1[int(temp1)-1])
            index2=newlist1.index(list1[int(temp2)-1])
            temp=""
            if str1[len(str1)-1]>='a' and str1[len(str1)-1]<='z':
                temp+=str1[len(str1)-1]
            newstr1=str(index1+1)+temp
            temp=""
            if str2[len(str2)-1]>='a' and str2[len(str2)-1]<='z':
                temp+=str2[len(str2)-1]
            newstr2=str(index2+1)+temp
            newlist2[len(newlist2)-1].append(newstr1)
            newlist2[len(newlist2)-1].append(newstr2)
            for j in range(2,len(list2[ans])):
                newlist2[len(newlist2)-1].append(list2[ans][j])
    PrintList(newlist1,newlist2)
    return 
def PrintList(list1,list2):
    for i in range(len(list1)):
        Str1=str(i+1)
        if len(list2[i])!=0:
            Str1+=' R['+list2[i][0]+','+list2[i][1]+']'
            for j in range(2,len(list2[i]),2):
                if j==2:
                    Str1+='{'
                Str1+=list2[i][j]+'='+list2[i][j+1]
                if j!=len(list2[i])-2:
                    Str1+=','
                else:
                    Str1+='}'
            Str1+=' ='
        Str2="("
        for j in range(len(list1[i])):
            Str2+=list1[i][j][0]
            for k in range(len(list1[i][j][1])):
                if k==0:
                    Str2+='('
                Str2+=list1[i][j][1][k]
                if k!=len(list1[i][j][1])-1:
                    Str2+=','
                else:
                    Str2+=')'
                    if len(list1[i])==1:
                        Str2+=','
            if j!=len(list1[i])-1:
                Str2+=','
            else:
                Str2+=')'
        if len(list1[i])==0:
            Str2+=')'
        print(Str1,Str2)
KB = {('A(tony)',),('A(mike)',),('A(john)',),('L(tony,rain)',),('L(tony,snow)',),('~A(x)','S(x)','C(x)'),('~C(y)','~L(y,rain)'),('L(z,snow)','~S(z)'),
('~L(tony,u)','~L(mike,u)'),('L(tony,v)','L(mike,v)'),('~A(w)','~C(w)','S(w)')}
ResolutionF0L(KB)